import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const ranking = await db
      .select({
        id: users.id,
        name: users.name,
        totalScore: users.totalScore,
        questionsAnswered: users.questionsAnswered,
        questionsCorrect: users.questionsCorrect,
        currentLevel: users.currentLevel,
      })
      .from(users)
      .orderBy(desc(users.totalScore))
      .limit(50);

    return NextResponse.json({ ranking });
  } catch (error) {
    console.error("Ranking error:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
