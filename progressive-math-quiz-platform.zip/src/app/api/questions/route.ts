import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { questions, userAnswers } from "@/db/schema";
import { eq, and, inArray, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");
    const category = searchParams.get("category");
    const difficulty = searchParams.get("difficulty");

    if (!userId) {
      return NextResponse.json(
        { error: "userId é obrigatório" },
        { status: 400 }
      );
    }

    // Get IDs of questions user already answered correctly
    const answeredCorrectly = await db
      .select({ questionId: userAnswers.questionId })
      .from(userAnswers)
      .where(
        and(
          eq(userAnswers.userId, parseInt(userId)),
          eq(userAnswers.isCorrect, true)
        )
      );

    const answeredIds = answeredCorrectly.map((a) => a.questionId);

    // Build conditions
    const conditions = [];
    if (category) {
      conditions.push(eq(questions.category, category));
    }
    if (difficulty) {
      conditions.push(eq(questions.difficulty, parseInt(difficulty)));
    }
    if (answeredIds.length > 0) {
      conditions.push(
        sql`${questions.id} NOT IN (${sql.join(
          answeredIds.map((id) => sql`${id}`),
          sql`, `
        )})`
      );
    }

    const whereClause =
      conditions.length > 0
        ? and(...conditions)
        : undefined;

    const result = await db
      .select({
        id: questions.id,
        category: questions.category,
        difficulty: questions.difficulty,
        statement: questions.statement,
        optionA: questions.optionA,
        optionB: questions.optionB,
        optionC: questions.optionC,
        optionD: questions.optionD,
        points: questions.points,
      })
      .from(questions)
      .where(whereClause)
      .orderBy(questions.difficulty, questions.id);

    return NextResponse.json({ questions: result });
  } catch (error) {
    console.error("Questions error:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
