import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { questions, userAnswers, users } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { userId, questionId, selectedOption } = await req.json();

    if (!userId || !questionId || !selectedOption) {
      return NextResponse.json(
        { error: "userId, questionId e selectedOption são obrigatórios" },
        { status: 400 }
      );
    }

    // Check if already answered correctly
    const alreadyCorrect = await db
      .select()
      .from(userAnswers)
      .where(
        and(
          eq(userAnswers.userId, userId),
          eq(userAnswers.questionId, questionId),
          eq(userAnswers.isCorrect, true)
        )
      )
      .limit(1);

    if (alreadyCorrect.length > 0) {
      return NextResponse.json(
        { error: "Você já respondeu esta questão corretamente" },
        { status: 400 }
      );
    }

    // Get the question
    const [question] = await db
      .select()
      .from(questions)
      .where(eq(questions.id, questionId))
      .limit(1);

    if (!question) {
      return NextResponse.json(
        { error: "Questão não encontrada" },
        { status: 404 }
      );
    }

    const isCorrect = selectedOption === question.correctOption;
    const pointsEarned = isCorrect ? question.points : 0;

    // Save the answer
    await db.insert(userAnswers).values({
      userId,
      questionId,
      selectedOption,
      isCorrect,
      pointsEarned,
    });

    // Update user stats
    if (isCorrect) {
      await db
        .update(users)
        .set({
          totalScore: sql`${users.totalScore} + ${pointsEarned}`,
          questionsAnswered: sql`${users.questionsAnswered} + 1`,
          questionsCorrect: sql`${users.questionsCorrect} + 1`,
          currentLevel: sql`LEAST(5, GREATEST(${users.currentLevel}, ${question.difficulty}))`,
        })
        .where(eq(users.id, userId));
    } else {
      await db
        .update(users)
        .set({
          questionsAnswered: sql`${users.questionsAnswered} + 1`,
        })
        .where(eq(users.id, userId));
    }

    // Get updated user
    const [updatedUser] = await db
      .select({
        id: users.id,
        name: users.name,
        totalScore: users.totalScore,
        questionsAnswered: users.questionsAnswered,
        questionsCorrect: users.questionsCorrect,
        currentLevel: users.currentLevel,
      })
      .from(users)
      .where(eq(users.id, userId));

    return NextResponse.json({
      isCorrect,
      correctOption: question.correctOption,
      explanation: question.explanation,
      pointsEarned,
      user: updatedUser,
    });
  } catch (error) {
    console.error("Answer error:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}
