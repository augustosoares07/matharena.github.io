"use client";

import { useState, useEffect, useCallback } from "react";

// ======== TYPES ========
interface User {
  id: number;
  name: string;
  email: string;
  totalScore: number;
  questionsAnswered: number;
  questionsCorrect: number;
  currentLevel: number;
}

interface Question {
  id: number;
  category: string;
  difficulty: number;
  statement: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  points: number;
}

interface AnswerResult {
  isCorrect: boolean;
  correctOption: string;
  explanation: string;
  pointsEarned: number;
  user: User;
}

interface RankedUser {
  id: number;
  name: string;
  totalScore: number;
  questionsAnswered: number;
  questionsCorrect: number;
  currentLevel: number;
}

type View = "home" | "login" | "register" | "practice" | "ranking" | "profile";

// ======== DIFFICULTY HELPERS ========
const difficultyLabels: Record<number, string> = {
  1: "Muito Fácil",
  2: "Fácil",
  3: "Médio",
  4: "Difícil",
  5: "Muito Difícil",
};

const difficultyColors: Record<number, string> = {
  1: "bg-emerald-500",
  2: "bg-green-500",
  3: "bg-amber-500",
  4: "bg-orange-500",
  5: "bg-rose-500",
};

const categoryLabels: Record<string, string> = {
  equacao_1grau: "Equações do 1º Grau",
  sistema_equacoes: "Sistemas de Equações",
};

// ======== MAIN COMPONENT ========
export default function Home() {
  const [view, setView] = useState<View>("home");
  const [user, setUser] = useState<User | null>(null);
  const [seeded, setSeeded] = useState(false);

  // Seed questions on first load
  useEffect(() => {
    if (!seeded) {
      fetch("/api/seed", { method: "POST" }).then(() => setSeeded(true));
    }
  }, [seeded]);

  // Restore session from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("mathArenaUser");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Refresh user data from DB
        fetch(`/api/user/${parsed.id}`)
          .then((r) => r.json())
          .then((data) => {
            if (data.user) {
              setUser(data.user);
              localStorage.setItem("mathArenaUser", JSON.stringify(data.user));
            }
          })
          .catch(() => {
            setUser(parsed);
          });
      } catch {
        localStorage.removeItem("mathArenaUser");
      }
    }
  }, []);

  const handleLogin = (u: User) => {
    setUser(u);
    localStorage.setItem("mathArenaUser", JSON.stringify(u));
    setView("home");
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("mathArenaUser");
    setView("home");
  };

  const updateUser = (u: User) => {
    setUser(u);
    localStorage.setItem("mathArenaUser", JSON.stringify(u));
  };

  return (
    <div className="min-h-screen">
      {/* Navbar */}
      <nav className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700/50 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => setView("home")}
            className="flex items-center gap-2 hover:opacity-80 transition"
          >
            <span className="text-2xl">🧮</span>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              MathArena
            </span>
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setView("ranking")}
              className="px-3 py-1.5 text-sm rounded-lg hover:bg-slate-700/50 transition flex items-center gap-1.5"
            >
              🏆 <span className="hidden sm:inline">Ranking</span>
            </button>

            {user ? (
              <>
                <button
                  onClick={() => setView("practice")}
                  className="px-3 py-1.5 text-sm rounded-lg bg-brand-600 hover:bg-brand-700 transition flex items-center gap-1.5"
                >
                  📝 <span className="hidden sm:inline">Praticar</span>
                </button>
                <button
                  onClick={() => setView("profile")}
                  className="px-3 py-1.5 text-sm rounded-lg hover:bg-slate-700/50 transition flex items-center gap-1.5"
                >
                  <span className="w-7 h-7 rounded-full bg-gradient-to-br from-brand-500 to-purple-500 flex items-center justify-center text-xs font-bold">
                    {user.name.charAt(0).toUpperCase()}
                  </span>
                  <span className="hidden sm:inline text-sm">{user.name}</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => setView("login")}
                className="px-4 py-1.5 text-sm rounded-lg bg-brand-600 hover:bg-brand-700 transition"
              >
                Entrar
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {view === "home" && <HomeView user={user} setView={setView} />}
        {view === "login" && (
          <LoginView onLogin={handleLogin} setView={setView} />
        )}
        {view === "register" && (
          <RegisterView onRegister={handleLogin} setView={setView} />
        )}
        {view === "practice" && user && (
          <PracticeView user={user} updateUser={updateUser} />
        )}
        {view === "ranking" && <RankingView currentUserId={user?.id} />}
        {view === "profile" && user && (
          <ProfileView user={user} onLogout={handleLogout} />
        )}
      </main>
    </div>
  );
}

// ======== HOME VIEW ========
function HomeView({
  user,
  setView,
}: {
  user: User | null;
  setView: (v: View) => void;
}) {
  return (
    <div className="animate-fadeIn">
      {/* Hero */}
      <div className="text-center py-12 sm:py-20">
        <h1 className="text-4xl sm:text-6xl font-extrabold mb-4">
          <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Domine Equações
          </span>
        </h1>
        <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto mb-8">
          Pratique equações do 1º grau e sistemas de equações com dificuldade
          progressiva. Ganhe pontos, suba no ranking e compita com seus colegas!
        </p>
        {user ? (
          <button
            onClick={() => setView("practice")}
            className="px-8 py-3 text-lg font-semibold rounded-xl bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-700 hover:to-purple-700 transition shadow-lg animate-pulse-glow"
          >
            Começar a Praticar 🚀
          </button>
        ) : (
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setView("register")}
              className="px-8 py-3 text-lg font-semibold rounded-xl bg-gradient-to-r from-brand-600 to-purple-600 hover:from-brand-700 hover:to-purple-700 transition shadow-lg"
            >
              Criar Conta Grátis
            </button>
            <button
              onClick={() => setView("login")}
              className="px-8 py-3 text-lg font-semibold rounded-xl border border-slate-600 hover:bg-slate-800 transition"
            >
              Já Tenho Conta
            </button>
          </div>
        )}
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-16">
        <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-6 border border-slate-700/50">
          <div className="text-4xl mb-4">📈</div>
          <h3 className="text-xl font-bold mb-2">Dificuldade Progressiva</h3>
          <p className="text-slate-400">
            5 níveis de dificuldade que vão do básico ao avançado. Evolua no seu
            ritmo!
          </p>
        </div>
        <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-6 border border-slate-700/50">
          <div className="text-4xl mb-4">💡</div>
          <h3 className="text-xl font-bold mb-2">Resolução Comentada</h3>
          <p className="text-slate-400">
            Ao acertar, veja a resolução passo a passo para consolidar seu
            aprendizado.
          </p>
        </div>
        <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-6 border border-slate-700/50">
          <div className="text-4xl mb-4">🏆</div>
          <h3 className="text-xl font-bold mb-2">Ranking Competitivo</h3>
          <p className="text-slate-400">
            Compare seu desempenho com outros alunos e dispute o topo do
            ranking!
          </p>
        </div>
      </div>

      {/* Categories */}
      <h2 className="text-2xl font-bold text-center mb-6">Categorias</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
        <div className="bg-gradient-to-br from-blue-900/40 to-blue-800/20 rounded-2xl p-6 border border-blue-700/30">
          <div className="text-3xl mb-3">➕</div>
          <h3 className="text-xl font-bold mb-2">Equações do 1º Grau</h3>
          <p className="text-slate-400 text-sm">
            Desde x + 3 = 7 até problemas contextualizados com interpretação de
            texto. Aprenda a isolar a incógnita e resolver qualquer equação
            linear.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {[1, 2, 3, 4, 5].map((d) => (
              <span
                key={d}
                className={`text-xs px-2 py-1 rounded-full ${difficultyColors[d]} text-white`}
              >
                Nível {d}
              </span>
            ))}
          </div>
        </div>
        <div className="bg-gradient-to-br from-purple-900/40 to-purple-800/20 rounded-2xl p-6 border border-purple-700/30">
          <div className="text-3xl mb-3">🔗</div>
          <h3 className="text-xl font-bold mb-2">Sistemas de Equações</h3>
          <p className="text-slate-400 text-sm">
            Do método da adição simples a problemas de lógica com múltiplas
            variáveis. Domine substituição, adição e resolução de sistemas.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {[1, 2, 3, 4, 5].map((d) => (
              <span
                key={d}
                className={`text-xs px-2 py-1 rounded-full ${difficultyColors[d]} text-white`}
              >
                Nível {d}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ======== LOGIN VIEW ========
function LoginView({
  onLogin,
  setView,
}: {
  onLogin: (u: User) => void;
  setView: (v: View) => void;
}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erro ao fazer login");
      } else {
        onLogin(data.user);
      }
    } catch {
      setError("Erro de conexão");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto animate-fadeIn">
      <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-8 border border-slate-700/50">
        <h2 className="text-2xl font-bold text-center mb-6">
          Entrar na sua conta
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-white"
              placeholder="seu@email.com"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Senha
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-white"
              placeholder="••••••"
              required
            />
          </div>
          {error && (
            <p className="text-rose-400 text-sm bg-rose-500/10 px-3 py-2 rounded-lg">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-brand-600 hover:bg-brand-700 disabled:opacity-50 font-semibold transition"
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
        <p className="text-center text-sm text-slate-400 mt-4">
          Não tem conta?{" "}
          <button
            onClick={() => setView("register")}
            className="text-brand-400 hover:underline"
          >
            Cadastre-se
          </button>
        </p>
      </div>
    </div>
  );
}

// ======== REGISTER VIEW ========
function RegisterView({
  onRegister,
  setView,
}: {
  onRegister: (u: User) => void;
  setView: (v: View) => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Erro ao cadastrar");
      } else {
        onRegister(data.user);
      }
    } catch {
      setError("Erro de conexão");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto animate-fadeIn">
      <div className="bg-slate-800/50 backdrop-blur rounded-2xl p-8 border border-slate-700/50">
        <h2 className="text-2xl font-bold text-center mb-6">Criar Conta</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Nome
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-white"
              placeholder="Seu nome"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-white"
              placeholder="seu@email.com"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Senha
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-white"
              placeholder="Mínimo 4 caracteres"
              required
              minLength={4}
            />
          </div>
          {error && (
            <p className="text-rose-400 text-sm bg-rose-500/10 px-3 py-2 rounded-lg">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-brand-600 hover:bg-brand-700 disabled:opacity-50 font-semibold transition"
          >
            {loading ? "Cadastrando..." : "Cadastrar"}
          </button>
        </form>
        <p className="text-center text-sm text-slate-400 mt-4">
          Já tem conta?{" "}
          <button
            onClick={() => setView("login")}
            className="text-brand-400 hover:underline"
          >
            Entrar
          </button>
        </p>
      </div>
    </div>
  );
}

// ======== PRACTICE VIEW ========
function PracticeView({
  user,
  updateUser,
}: {
  user: User;
  updateUser: (u: User) => void;
}) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [result, setResult] = useState<AnswerResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");

  const loadQuestions = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams({ userId: user.id.toString() });
    if (selectedCategory !== "all") params.set("category", selectedCategory);
    if (selectedDifficulty !== "all")
      params.set("difficulty", selectedDifficulty);

    try {
      const res = await fetch(`/api/questions?${params}`);
      const data = await res.json();
      setQuestions(data.questions || []);
      setCurrentIndex(0);
      setSelectedOption(null);
      setResult(null);
    } catch {
      console.error("Erro ao carregar questões");
    } finally {
      setLoading(false);
    }
  }, [user.id, selectedCategory, selectedDifficulty]);

  useEffect(() => {
    loadQuestions();
  }, [loadQuestions]);

  const handleSubmitAnswer = async () => {
    if (!selectedOption || !currentQuestion) return;
    setSubmitting(true);

    try {
      const res = await fetch("/api/answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          questionId: currentQuestion.id,
          selectedOption,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setResult(data);
        updateUser(data.user);
      }
    } catch {
      console.error("Erro ao enviar resposta");
    } finally {
      setSubmitting(false);
    }
  };

  const handleNext = () => {
    if (result?.isCorrect) {
      // Remove answered question from list
      const newQuestions = questions.filter(
        (_, i) => i !== currentIndex
      );
      setQuestions(newQuestions);
      setCurrentIndex(Math.min(currentIndex, newQuestions.length - 1));
    } else {
      setCurrentIndex(
        currentIndex < questions.length - 1 ? currentIndex + 1 : 0
      );
    }
    setSelectedOption(null);
    setResult(null);
  };

  const currentQuestion = questions[currentIndex];
  const optionLabels = ["A", "B", "C", "D"] as const;

  if (loading) {
    return (
      <div className="text-center py-20">
        <div className="inline-block w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-4 text-slate-400">Carregando questões...</p>
      </div>
    );
  }

  return (
    <div className="animate-fadeIn">
      {/* Stats Bar */}
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="bg-slate-800/50 rounded-xl px-4 py-2 border border-slate-700/50 flex items-center gap-2">
          <span className="text-amber-400">⭐</span>
          <span className="font-bold">{user.totalScore}</span>
          <span className="text-sm text-slate-400">pontos</span>
        </div>
        <div className="bg-slate-800/50 rounded-xl px-4 py-2 border border-slate-700/50 flex items-center gap-2">
          <span className="text-emerald-400">✅</span>
          <span className="font-bold">{user.questionsCorrect}</span>
          <span className="text-sm text-slate-400">acertos</span>
        </div>
        <div className="bg-slate-800/50 rounded-xl px-4 py-2 border border-slate-700/50 flex items-center gap-2">
          <span className="text-blue-400">📊</span>
          <span className="font-bold">
            {user.questionsAnswered > 0
              ? Math.round(
                  (user.questionsCorrect / user.questionsAnswered) * 100
                )
              : 0}
            %
          </span>
          <span className="text-sm text-slate-400">aproveitamento</span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6">
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-4 py-2 bg-slate-800/80 border border-slate-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
        >
          <option value="all">Todas as categorias</option>
          <option value="equacao_1grau">Equações do 1º Grau</option>
          <option value="sistema_equacoes">Sistemas de Equações</option>
        </select>
        <select
          value={selectedDifficulty}
          onChange={(e) => setSelectedDifficulty(e.target.value)}
          className="px-4 py-2 bg-slate-800/80 border border-slate-600 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
        >
          <option value="all">Todas as dificuldades</option>
          {[1, 2, 3, 4, 5].map((d) => (
            <option key={d} value={d.toString()}>
              Nível {d} - {difficultyLabels[d]}
            </option>
          ))}
        </select>
      </div>

      {/* Question */}
      {!currentQuestion ? (
        <div className="text-center py-16 bg-slate-800/30 rounded-2xl border border-slate-700/50">
          <div className="text-6xl mb-4">🎉</div>
          <h3 className="text-2xl font-bold mb-2">Parabéns!</h3>
          <p className="text-slate-400 mb-6">
            Você completou todas as questões desta categoria/dificuldade!
          </p>
          <button
            onClick={() => {
              setSelectedCategory("all");
              setSelectedDifficulty("all");
            }}
            className="px-6 py-2.5 rounded-lg bg-brand-600 hover:bg-brand-700 transition"
          >
            Ver todas as questões
          </button>
        </div>
      ) : (
        <div className="bg-slate-800/50 backdrop-blur rounded-2xl border border-slate-700/50 overflow-hidden">
          {/* Question Header */}
          <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/50 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span
                className={`text-xs font-bold px-3 py-1 rounded-full text-white ${
                  difficultyColors[currentQuestion.difficulty]
                }`}
              >
                {difficultyLabels[currentQuestion.difficulty]}
              </span>
              <span className="text-sm text-slate-400">
                {categoryLabels[currentQuestion.category]}
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-amber-400">+{currentQuestion.points} pts</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400">
                {currentIndex + 1} de {questions.length}
              </span>
            </div>
          </div>

          {/* Statement */}
          <div className="px-6 py-6">
            <p className="text-lg font-medium whitespace-pre-line leading-relaxed">
              {currentQuestion.statement}
            </p>
          </div>

          {/* Options */}
          <div className="px-6 pb-6 space-y-3">
            {optionLabels.map((label) => {
              const optionKey =
                `option${label}` as keyof Question;
              const optionText = currentQuestion[optionKey] as string;
              const isSelected = selectedOption === label;
              const isAnswered = result !== null;
              const isCorrectOption = result?.correctOption === label;
              const isWrongSelection =
                isAnswered && isSelected && !result?.isCorrect;

              let btnClass =
                "w-full text-left px-5 py-3.5 rounded-xl border-2 transition-all duration-200 ";

              if (isAnswered) {
                if (isCorrectOption) {
                  btnClass +=
                    "border-emerald-500 bg-emerald-500/10 text-emerald-300";
                } else if (isWrongSelection) {
                  btnClass +=
                    "border-rose-500 bg-rose-500/10 text-rose-300 line-through";
                } else {
                  btnClass +=
                    "border-slate-700 bg-slate-800/30 text-slate-500";
                }
              } else if (isSelected) {
                btnClass +=
                  "border-brand-500 bg-brand-500/10 text-white ring-2 ring-brand-500/30";
              } else {
                btnClass +=
                  "border-slate-700 bg-slate-800/30 hover:border-slate-500 hover:bg-slate-700/30 text-slate-200";
              }

              return (
                <button
                  key={label}
                  onClick={() => !isAnswered && setSelectedOption(label)}
                  disabled={isAnswered}
                  className={btnClass}
                >
                  <span className="flex items-center gap-3">
                    <span
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${
                        isAnswered && isCorrectOption
                          ? "bg-emerald-500 text-white"
                          : isWrongSelection
                          ? "bg-rose-500 text-white"
                          : isSelected
                          ? "bg-brand-500 text-white"
                          : "bg-slate-700 text-slate-300"
                      }`}
                    >
                      {isAnswered && isCorrectOption
                        ? "✓"
                        : isWrongSelection
                        ? "✗"
                        : label}
                    </span>
                    <span>{optionText}</span>
                  </span>
                </button>
              );
            })}
          </div>

          {/* Submit / Result */}
          <div className="px-6 pb-6">
            {!result ? (
              <button
                onClick={handleSubmitAnswer}
                disabled={!selectedOption || submitting}
                className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-700 disabled:opacity-40 disabled:cursor-not-allowed font-semibold transition text-lg"
              >
                {submitting ? "Verificando..." : "Confirmar Resposta"}
              </button>
            ) : (
              <div className="animate-slideUp">
                {/* Result Banner */}
                <div
                  className={`p-4 rounded-xl mb-4 ${
                    result.isCorrect
                      ? "bg-emerald-500/10 border border-emerald-500/30"
                      : "bg-rose-500/10 border border-rose-500/30"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-2xl">
                      {result.isCorrect ? "🎉" : "❌"}
                    </span>
                    <span
                      className={`font-bold text-lg ${
                        result.isCorrect
                          ? "text-emerald-400"
                          : "text-rose-400"
                      }`}
                    >
                      {result.isCorrect
                        ? `Correto! +${result.pointsEarned} pontos`
                        : "Incorreto!"}
                    </span>
                  </div>
                  {!result.isCorrect && (
                    <p className="text-slate-400 text-sm">
                      A resposta correta é a alternativa{" "}
                      <strong className="text-emerald-400">
                        {result.correctOption}
                      </strong>
                      . Tente novamente para ver a resolução comentada!
                    </p>
                  )}
                </div>

                {/* Explanation (only when correct) */}
                {result.isCorrect && (
                  <div className="bg-slate-900/50 rounded-xl p-5 border border-slate-700/50 mb-4">
                    <h4 className="font-bold text-brand-400 mb-3 flex items-center gap-2">
                      💡 Resolução Comentada
                    </h4>
                    <p className="text-slate-300 whitespace-pre-line leading-relaxed text-sm">
                      {result.explanation}
                    </p>
                  </div>
                )}

                <button
                  onClick={handleNext}
                  className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-700 font-semibold transition text-lg"
                >
                  {result.isCorrect
                    ? "Próxima Questão →"
                    : "Tentar Outra →"}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ======== RANKING VIEW ========
function RankingView({ currentUserId }: { currentUserId?: number }) {
  const [ranking, setRanking] = useState<RankedUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/ranking")
      .then((r) => r.json())
      .then((data) => setRanking(data.ranking || []))
      .finally(() => setLoading(false));
  }, []);

  const medals = ["🥇", "🥈", "🥉"];

  if (loading) {
    return (
      <div className="text-center py-20">
        <div className="inline-block w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto animate-fadeIn">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-extrabold mb-2">🏆 Ranking</h2>
        <p className="text-slate-400">
          Os melhores alunos em equações matemáticas
        </p>
      </div>

      {ranking.length === 0 ? (
        <div className="text-center py-16 bg-slate-800/30 rounded-2xl border border-slate-700/50">
          <div className="text-5xl mb-4">🏜️</div>
          <p className="text-slate-400">
            Nenhum aluno cadastrado ainda. Seja o primeiro!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {ranking.map((u, i) => (
            <div
              key={u.id}
              className={`flex items-center gap-4 px-5 py-4 rounded-xl border transition ${
                u.id === currentUserId
                  ? "bg-brand-600/10 border-brand-500/40 ring-1 ring-brand-500/20"
                  : "bg-slate-800/50 border-slate-700/50"
              } ${i < 3 ? "shadow-lg" : ""}`}
            >
              {/* Position */}
              <div className="w-10 text-center text-xl font-bold shrink-0">
                {i < 3 ? medals[i] : <span className="text-slate-500">{i + 1}</span>}
              </div>

              {/* Avatar */}
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white shrink-0 ${
                  i === 0
                    ? "bg-gradient-to-br from-yellow-400 to-amber-600"
                    : i === 1
                    ? "bg-gradient-to-br from-slate-300 to-slate-500"
                    : i === 2
                    ? "bg-gradient-to-br from-amber-600 to-amber-800"
                    : "bg-gradient-to-br from-brand-500 to-purple-500"
                }`}
              >
                {u.name.charAt(0).toUpperCase()}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="font-semibold truncate">
                  {u.name}
                  {u.id === currentUserId && (
                    <span className="text-brand-400 text-xs ml-2">(você)</span>
                  )}
                </p>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span>Nível {u.currentLevel}</span>
                  <span>•</span>
                  <span>
                    {u.questionsCorrect}/{u.questionsAnswered} acertos
                  </span>
                  <span>•</span>
                  <span>
                    {u.questionsAnswered > 0
                      ? Math.round(
                          (u.questionsCorrect / u.questionsAnswered) * 100
                        )
                      : 0}
                    %
                  </span>
                </div>
              </div>

              {/* Score */}
              <div className="text-right shrink-0">
                <p className="text-xl font-bold text-amber-400">
                  {u.totalScore}
                </p>
                <p className="text-xs text-slate-500">pontos</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ======== PROFILE VIEW ========
function ProfileView({
  user,
  onLogout,
}: {
  user: User;
  onLogout: () => void;
}) {
  const accuracy =
    user.questionsAnswered > 0
      ? Math.round((user.questionsCorrect / user.questionsAnswered) * 100)
      : 0;

  const levelProgress = Math.min(100, (user.currentLevel / 5) * 100);

  return (
    <div className="max-w-lg mx-auto animate-fadeIn">
      <div className="bg-slate-800/50 backdrop-blur rounded-2xl border border-slate-700/50 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-brand-600 to-purple-600 p-8 text-center">
          <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-3xl font-bold mx-auto mb-3">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <h2 className="text-2xl font-bold">{user.name}</h2>
          <p className="text-blue-200 text-sm">{user.email}</p>
        </div>

        {/* Stats */}
        <div className="p-6 space-y-6">
          {/* Level */}
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium text-slate-300">
                Nível Atual
              </span>
              <span className="text-sm font-bold text-brand-400">
                {user.currentLevel} / 5 — {difficultyLabels[user.currentLevel]}
              </span>
            </div>
            <div className="w-full h-3 bg-slate-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-brand-500 to-purple-500 rounded-full transition-all duration-500"
                style={{ width: `${levelProgress}%` }}
              />
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-900/50 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-amber-400">
                {user.totalScore}
              </p>
              <p className="text-xs text-slate-400 mt-1">Pontos Totais</p>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-emerald-400">{accuracy}%</p>
              <p className="text-xs text-slate-400 mt-1">Aproveitamento</p>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-blue-400">
                {user.questionsCorrect}
              </p>
              <p className="text-xs text-slate-400 mt-1">Questões Corretas</p>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-slate-300">
                {user.questionsAnswered}
              </p>
              <p className="text-xs text-slate-400 mt-1">Total Respondidas</p>
            </div>
          </div>

          {/* Logout */}
          <button
            onClick={onLogout}
            className="w-full py-2.5 rounded-lg border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 transition font-medium"
          >
            Sair da Conta
          </button>
        </div>
      </div>
    </div>
  );
}
