import { db } from "./index";
import { questions } from "./schema";

const seedQuestions = [
  // ========== EQUAÇÕES DO 1º GRAU - Nível 1 (Muito Fácil) ==========
  {
    category: "equacao_1grau",
    difficulty: 1,
    statement: "Resolva a equação: x + 3 = 7",
    optionA: "x = 4",
    optionB: "x = 3",
    optionC: "x = 10",
    optionD: "x = 5",
    correctOption: "A",
    explanation:
      "Para resolver x + 3 = 7, isolamos x subtraindo 3 de ambos os lados:\nx + 3 - 3 = 7 - 3\nx = 4\n\nVerificação: 4 + 3 = 7 ✓",
    points: 10,
  },
  {
    category: "equacao_1grau",
    difficulty: 1,
    statement: "Resolva a equação: x - 5 = 2",
    optionA: "x = 3",
    optionB: "x = 7",
    optionC: "x = -3",
    optionD: "x = 10",
    correctOption: "B",
    explanation:
      "Para resolver x - 5 = 2, somamos 5 em ambos os lados:\nx - 5 + 5 = 2 + 5\nx = 7\n\nVerificação: 7 - 5 = 2 ✓",
    points: 10,
  },
  {
    category: "equacao_1grau",
    difficulty: 1,
    statement: "Resolva a equação: 2x = 10",
    optionA: "x = 20",
    optionB: "x = 8",
    optionC: "x = 5",
    optionD: "x = 12",
    correctOption: "C",
    explanation:
      "Para resolver 2x = 10, dividimos ambos os lados por 2:\n2x ÷ 2 = 10 ÷ 2\nx = 5\n\nVerificação: 2 × 5 = 10 ✓",
    points: 10,
  },
  {
    category: "equacao_1grau",
    difficulty: 1,
    statement: "Resolva a equação: x + 1 = 6",
    optionA: "x = 7",
    optionB: "x = 6",
    optionC: "x = 4",
    optionD: "x = 5",
    correctOption: "D",
    explanation:
      "Para resolver x + 1 = 6, subtraímos 1 de ambos os lados:\nx + 1 - 1 = 6 - 1\nx = 5\n\nVerificação: 5 + 1 = 6 ✓",
    points: 10,
  },

  // ========== EQUAÇÕES DO 1º GRAU - Nível 2 (Fácil) ==========
  {
    category: "equacao_1grau",
    difficulty: 2,
    statement: "Resolva a equação: 3x + 4 = 19",
    optionA: "x = 7",
    optionB: "x = 3",
    optionC: "x = 5",
    optionD: "x = 6",
    correctOption: "C",
    explanation:
      "Passo 1: Subtrair 4 de ambos os lados:\n3x + 4 - 4 = 19 - 4\n3x = 15\n\nPasso 2: Dividir ambos os lados por 3:\nx = 15 ÷ 3\nx = 5\n\nVerificação: 3(5) + 4 = 15 + 4 = 19 ✓",
    points: 15,
  },
  {
    category: "equacao_1grau",
    difficulty: 2,
    statement: "Resolva a equação: 2x - 3 = 11",
    optionA: "x = 4",
    optionB: "x = 7",
    optionC: "x = 8",
    optionD: "x = 5",
    correctOption: "B",
    explanation:
      "Passo 1: Somar 3 em ambos os lados:\n2x - 3 + 3 = 11 + 3\n2x = 14\n\nPasso 2: Dividir ambos os lados por 2:\nx = 14 ÷ 2\nx = 7\n\nVerificação: 2(7) - 3 = 14 - 3 = 11 ✓",
    points: 15,
  },
  {
    category: "equacao_1grau",
    difficulty: 2,
    statement: "Resolva a equação: 5x - 10 = 15",
    optionA: "x = 1",
    optionB: "x = 25",
    optionC: "x = 3",
    optionD: "x = 5",
    correctOption: "D",
    explanation:
      "Passo 1: Somar 10 em ambos os lados:\n5x - 10 + 10 = 15 + 10\n5x = 25\n\nPasso 2: Dividir ambos os lados por 5:\nx = 25 ÷ 5\nx = 5\n\nVerificação: 5(5) - 10 = 25 - 10 = 15 ✓",
    points: 15,
  },
  {
    category: "equacao_1grau",
    difficulty: 2,
    statement: "Resolva a equação: 4x + 2 = 18",
    optionA: "x = 4",
    optionB: "x = 5",
    optionC: "x = 3",
    optionD: "x = 6",
    correctOption: "A",
    explanation:
      "Passo 1: Subtrair 2 de ambos os lados:\n4x + 2 - 2 = 18 - 2\n4x = 16\n\nPasso 2: Dividir ambos os lados por 4:\nx = 16 ÷ 4\nx = 4\n\nVerificação: 4(4) + 2 = 16 + 2 = 18 ✓",
    points: 15,
  },

  // ========== EQUAÇÕES DO 1º GRAU - Nível 3 (Médio) ==========
  {
    category: "equacao_1grau",
    difficulty: 3,
    statement: "Resolva a equação: 3(x - 2) = 2x + 1",
    optionA: "x = 5",
    optionB: "x = 3",
    optionC: "x = 7",
    optionD: "x = -1",
    correctOption: "C",
    explanation:
      "Passo 1: Distribuir o 3:\n3x - 6 = 2x + 1\n\nPasso 2: Passar 2x para o lado esquerdo:\n3x - 2x - 6 = 1\nx - 6 = 1\n\nPasso 3: Somar 6 em ambos os lados:\nx = 1 + 6\nx = 7\n\nVerificação: 3(7-2) = 3(5) = 15 e 2(7)+1 = 15 ✓",
    points: 20,
  },
  {
    category: "equacao_1grau",
    difficulty: 3,
    statement: "Resolva a equação: 2(x + 3) - 4 = x + 8",
    optionA: "x = 4",
    optionB: "x = 6",
    optionC: "x = 8",
    optionD: "x = 2",
    correctOption: "B",
    explanation:
      "Passo 1: Distribuir o 2:\n2x + 6 - 4 = x + 8\n2x + 2 = x + 8\n\nPasso 2: Passar x para o lado esquerdo:\n2x - x + 2 = 8\nx + 2 = 8\n\nPasso 3: Subtrair 2:\nx = 8 - 2\nx = 6\n\nVerificação: 2(6+3) - 4 = 2(9) - 4 = 14 e 6+8 = 14 ✓",
    points: 20,
  },
  {
    category: "equacao_1grau",
    difficulty: 3,
    statement: "Resolva a equação: 5x - 3 = 2x + 9",
    optionA: "x = 2",
    optionB: "x = 3",
    optionC: "x = 4",
    optionD: "x = 6",
    correctOption: "C",
    explanation:
      "Passo 1: Passar 2x para o lado esquerdo:\n5x - 2x - 3 = 9\n3x - 3 = 9\n\nPasso 2: Somar 3 em ambos os lados:\n3x = 12\n\nPasso 3: Dividir por 3:\nx = 12 ÷ 3\nx = 4\n\nVerificação: 5(4) - 3 = 17 e 2(4) + 9 = 17 ✓",
    points: 20,
  },
  {
    category: "equacao_1grau",
    difficulty: 3,
    statement: "Resolva a equação: 7x - 2(x + 3) = 14",
    optionA: "x = 2",
    optionB: "x = 3",
    optionC: "x = 4",
    optionD: "x = 5",
    correctOption: "C",
    explanation:
      "Passo 1: Distribuir o -2:\n7x - 2x - 6 = 14\n5x - 6 = 14\n\nPasso 2: Somar 6 em ambos os lados:\n5x = 20\n\nPasso 3: Dividir por 5:\nx = 20 ÷ 5\nx = 4\n\nVerificação: 7(4) - 2(4+3) = 28 - 14 = 14 ✓",
    points: 20,
  },

  // ========== EQUAÇÕES DO 1º GRAU - Nível 4 (Difícil) ==========
  {
    category: "equacao_1grau",
    difficulty: 4,
    statement: "Resolva a equação: 4(2x - 1) - 3(x + 2) = 2(x - 5)",
    optionA: "x = 0",
    optionB: "x = -2",
    optionC: "x = 2",
    optionD: "x = 1",
    correctOption: "A",
    explanation:
      "Passo 1: Distribuir:\n8x - 4 - 3x - 6 = 2x - 10\n5x - 10 = 2x - 10\n\nPasso 2: Passar 2x para a esquerda:\n5x - 2x - 10 = -10\n3x - 10 = -10\n\nPasso 3: Somar 10:\n3x = 0\nx = 0\n\nVerificação: 4(0-1) - 3(0+2) = -4 - 6 = -10 e 2(0-5) = -10 ✓",
    points: 25,
  },
  {
    category: "equacao_1grau",
    difficulty: 4,
    statement: "Resolva a equação: (2x + 1)/3 = (x + 4)/2",
    optionA: "x = 7",
    optionB: "x = 8",
    optionC: "x = 10",
    optionD: "x = 12",
    correctOption: "C",
    explanation:
      "Passo 1: Multiplicar ambos os lados pelo MMC (6):\n6 · (2x + 1)/3 = 6 · (x + 4)/2\n2(2x + 1) = 3(x + 4)\n\nPasso 2: Distribuir:\n4x + 2 = 3x + 12\n\nPasso 3: Isolar x:\n4x - 3x = 12 - 2\nx = 10\n\nVerificação: (2·10 + 1)/3 = 21/3 = 7 e (10 + 4)/2 = 14/2 = 7 ✓",
    points: 25,
  },
  {
    category: "equacao_1grau",
    difficulty: 4,
    statement: "Resolva a equação: 3(2x + 1) = 5(x - 1) + 14",
    optionA: "x = 4",
    optionB: "x = 6",
    optionC: "x = 8",
    optionD: "x = 3",
    correctOption: "B",
    explanation:
      "Passo 1: Distribuir:\n6x + 3 = 5x - 5 + 14\n6x + 3 = 5x + 9\n\nPasso 2: Passar 5x para a esquerda:\n6x - 5x + 3 = 9\nx + 3 = 9\n\nPasso 3: Subtrair 3:\nx = 6\n\nVerificação: 3(2·6 + 1) = 3(13) = 39 e 5(6-1) + 14 = 25 + 14 = 39 ✓",
    points: 25,
  },

  // ========== EQUAÇÕES DO 1º GRAU - Nível 5 (Muito Difícil) ==========
  {
    category: "equacao_1grau",
    difficulty: 5,
    statement:
      "A idade de Pedro é o dobro da idade de João. Daqui a 5 anos, a soma das idades deles será 55. Qual a idade atual de João?",
    optionA: "10 anos",
    optionB: "15 anos",
    optionC: "20 anos",
    optionD: "25 anos",
    correctOption: "B",
    explanation:
      "Passo 1: Definir variáveis:\nIdade de João = x\nIdade de Pedro = 2x\n\nPasso 2: Daqui a 5 anos:\nIdade de João = x + 5\nIdade de Pedro = 2x + 5\n\nPasso 3: Soma das idades daqui a 5 anos = 55:\n(x + 5) + (2x + 5) = 55\n3x + 10 = 55\n3x = 45\nx = 15\n\nJoão tem 15 anos e Pedro tem 30 anos.\nVerificação: Daqui a 5 anos: 20 + 35 = 55 ✓",
    points: 30,
  },
  {
    category: "equacao_1grau",
    difficulty: 5,
    statement:
      "Um retângulo tem perímetro de 56 cm. O comprimento é 4 cm a mais que o dobro da largura. Qual é a largura?",
    optionA: "6 cm",
    optionB: "8 cm",
    optionC: "10 cm",
    optionD: "12 cm",
    correctOption: "B",
    explanation:
      "Passo 1: Definir variáveis:\nLargura = x\nComprimento = 2x + 4\n\nPasso 2: Fórmula do perímetro:\n2(largura + comprimento) = 56\n2(x + 2x + 4) = 56\n2(3x + 4) = 56\n\nPasso 3: Resolver:\n6x + 8 = 56\n6x = 48\nx = 8\n\nLargura = 8 cm, Comprimento = 2(8) + 4 = 20 cm\nVerificação: 2(8 + 20) = 2(28) = 56 ✓",
    points: 30,
  },
  {
    category: "equacao_1grau",
    difficulty: 5,
    statement:
      "Maria tem o triplo da quantia de Ana. Se Maria der R$ 20 para Ana, ambas ficarão com a mesma quantia. Quanto Maria tem?",
    optionA: "R$ 40",
    optionB: "R$ 50",
    optionC: "R$ 60",
    optionD: "R$ 80",
    correctOption: "C",
    explanation:
      "Passo 1: Definir variáveis:\nAna = x\nMaria = 3x\n\nPasso 2: Se Maria der R$ 20 para Ana:\nMaria fica com: 3x - 20\nAna fica com: x + 20\n\nPasso 3: Igualar (ficam com a mesma quantia):\n3x - 20 = x + 20\n3x - x = 20 + 20\n2x = 40\nx = 20\n\nMaria tem 3(20) = R$ 60\n\nVerificação: Maria: 60 - 20 = 40, Ana: 20 + 20 = 40 ✓",
    points: 30,
  },

  // ========== SISTEMAS DE EQUAÇÕES - Nível 1 (Muito Fácil) ==========
  {
    category: "sistema_equacoes",
    difficulty: 1,
    statement:
      "Resolva o sistema:\nx + y = 5\nx - y = 1\nQual o valor de x?",
    optionA: "x = 2",
    optionB: "x = 3",
    optionC: "x = 4",
    optionD: "x = 1",
    correctOption: "B",
    explanation:
      "Método da adição:\nSomando as duas equações:\n(x + y) + (x - y) = 5 + 1\n2x = 6\nx = 3\n\nSubstituindo em x + y = 5:\n3 + y = 5 → y = 2\n\nSolução: x = 3 e y = 2\nVerificação: 3 + 2 = 5 ✓ e 3 - 2 = 1 ✓",
    points: 10,
  },
  {
    category: "sistema_equacoes",
    difficulty: 1,
    statement:
      "Resolva o sistema:\nx + y = 10\nx - y = 4\nQual o valor de y?",
    optionA: "y = 7",
    optionB: "y = 4",
    optionC: "y = 3",
    optionD: "y = 5",
    correctOption: "C",
    explanation:
      "Somando as equações:\n(x + y) + (x - y) = 10 + 4\n2x = 14 → x = 7\n\nSubstituindo: 7 + y = 10 → y = 3\n\nVerificação: 7 + 3 = 10 ✓ e 7 - 3 = 4 ✓",
    points: 10,
  },
  {
    category: "sistema_equacoes",
    difficulty: 1,
    statement:
      "Resolva o sistema:\nx + y = 7\ny = 3\nQual o valor de x?",
    optionA: "x = 3",
    optionB: "x = 7",
    optionC: "x = 4",
    optionD: "x = 10",
    correctOption: "C",
    explanation:
      "Como y = 3, substituímos na primeira equação:\nx + 3 = 7\nx = 7 - 3\nx = 4\n\nSolução: x = 4 e y = 3\nVerificação: 4 + 3 = 7 ✓",
    points: 10,
  },

  // ========== SISTEMAS DE EQUAÇÕES - Nível 2 (Fácil) ==========
  {
    category: "sistema_equacoes",
    difficulty: 2,
    statement:
      "Resolva o sistema:\n2x + y = 7\nx - y = 2\nQual o valor de x?",
    optionA: "x = 2",
    optionB: "x = 3",
    optionC: "x = 4",
    optionD: "x = 1",
    correctOption: "B",
    explanation:
      "Somando as duas equações:\n(2x + y) + (x - y) = 7 + 2\n3x = 9\nx = 3\n\nSubstituindo: 3 - y = 2 → y = 1\n\nVerificação: 2(3) + 1 = 7 ✓ e 3 - 1 = 2 ✓",
    points: 15,
  },
  {
    category: "sistema_equacoes",
    difficulty: 2,
    statement:
      "Resolva o sistema:\n3x + 2y = 12\nx + 2y = 8\nQual o valor de x?",
    optionA: "x = 1",
    optionB: "x = 2",
    optionC: "x = 3",
    optionD: "x = 4",
    correctOption: "B",
    explanation:
      "Subtraindo a segunda da primeira:\n(3x + 2y) - (x + 2y) = 12 - 8\n2x = 4\nx = 2\n\nSubstituindo: 2 + 2y = 8 → 2y = 6 → y = 3\n\nVerificação: 3(2) + 2(3) = 12 ✓ e 2 + 2(3) = 8 ✓",
    points: 15,
  },
  {
    category: "sistema_equacoes",
    difficulty: 2,
    statement:
      "Resolva o sistema:\nx + 3y = 11\nx + y = 5\nQual o valor de y?",
    optionA: "y = 2",
    optionB: "y = 3",
    optionC: "y = 4",
    optionD: "y = 1",
    correctOption: "B",
    explanation:
      "Subtraindo a segunda da primeira:\n(x + 3y) - (x + y) = 11 - 5\n2y = 6\ny = 3\n\nSubstituindo: x + 3 = 5 → x = 2\n\nVerificação: 2 + 3(3) = 11 ✓ e 2 + 3 = 5 ✓",
    points: 15,
  },

  // ========== SISTEMAS DE EQUAÇÕES - Nível 3 (Médio) ==========
  {
    category: "sistema_equacoes",
    difficulty: 3,
    statement:
      "Resolva o sistema:\n2x + 3y = 16\n3x - 2y = 11\nQual o valor de x + y?",
    optionA: "x + y = 6",
    optionB: "x + y = 7",
    optionC: "x + y = 8",
    optionD: "x + y = 9",
    correctOption: "B",
    explanation:
      "Multiplicando a 1ª por 2 e a 2ª por 3:\n4x + 6y = 32\n9x - 6y = 33\n\nSomando:\n13x = 65\nx = 5\n\nSubstituindo na 1ª: 10 + 3y = 16 → 3y = 6 → y = 2\n\nx + y = 5 + 2 = 7\n\nVerificação: 2(5) + 3(2) = 16 ✓ e 3(5) - 2(2) = 11 ✓",
    points: 20,
  },
  {
    category: "sistema_equacoes",
    difficulty: 3,
    statement:
      "Resolva o sistema:\n4x - y = 10\n2x + 3y = 12\nQual o valor de y?",
    optionA: "y = 1",
    optionB: "y = 2",
    optionC: "y = 3",
    optionD: "y = 4",
    correctOption: "B",
    explanation:
      "Da 1ª equação: y = 4x - 10\n\nSubstituindo na 2ª:\n2x + 3(4x - 10) = 12\n2x + 12x - 30 = 12\n14x = 42\nx = 3\n\ny = 4(3) - 10 = 2\n\nVerificação: 4(3) - 2 = 10 ✓ e 2(3) + 3(2) = 12 ✓",
    points: 20,
  },

  // ========== SISTEMAS DE EQUAÇÕES - Nível 4 (Difícil) ==========
  {
    category: "sistema_equacoes",
    difficulty: 4,
    statement:
      "Resolva o sistema:\n(x/2) + (y/3) = 5\n(x/3) - (y/2) = -1\nQual o valor de x?",
    optionA: "x = 4",
    optionB: "x = 6",
    optionC: "x = 8",
    optionD: "x = 2",
    correctOption: "B",
    explanation:
      "Passo 1: Multiplicar a 1ª por 6:\n3x + 2y = 30\n\nPasso 2: Multiplicar a 2ª por 6:\n2x - 3y = -6\n\nPasso 3: Multiplicar a nova 1ª por 3 e a nova 2ª por 2:\n9x + 6y = 90\n4x - 6y = -12\n\nSomando:\n13x = 78\nx = 6\n\nSubstituindo: 3(6) + 2y = 30 → 18 + 2y = 30 → y = 6\n\nVerificação: 6/2 + 6/3 = 3 + 2 = 5 ✓ e 6/3 - 6/2 = 2 - 3 = -1 ✓",
    points: 25,
  },
  {
    category: "sistema_equacoes",
    difficulty: 4,
    statement:
      "Dois números têm soma 50. O dobro do maior menos o triplo do menor é igual a 10. Qual é o maior número?",
    optionA: "28",
    optionB: "30",
    optionC: "32",
    optionD: "34",
    correctOption: "C",
    explanation:
      "Seja x o maior e y o menor.\n\nSistema:\nx + y = 50\n2x - 3y = 10\n\nDa 1ª: y = 50 - x\n\nSubstituindo na 2ª:\n2x - 3(50 - x) = 10\n2x - 150 + 3x = 10\n5x = 160\nx = 32\n\ny = 50 - 32 = 18\n\nVerificação: 32 + 18 = 50 ✓ e 2(32) - 3(18) = 64 - 54 = 10 ✓",
    points: 25,
  },

  // ========== SISTEMAS DE EQUAÇÕES - Nível 5 (Muito Difícil) ==========
  {
    category: "sistema_equacoes",
    difficulty: 5,
    statement:
      "Um fazendeiro tem galinhas e coelhos. No total são 35 cabeças e 94 patas. Quantas galinhas ele tem?",
    optionA: "18 galinhas",
    optionB: "20 galinhas",
    optionC: "23 galinhas",
    optionD: "25 galinhas",
    correctOption: "C",
    explanation:
      "Seja g = galinhas e c = coelhos.\n\nSistema:\ng + c = 35 (cabeças)\n2g + 4c = 94 (patas)\n\nDa 1ª: g = 35 - c\n\nSubstituindo na 2ª:\n2(35 - c) + 4c = 94\n70 - 2c + 4c = 94\n2c = 24\nc = 12\n\ng = 35 - 12 = 23\n\nVerificação: 23 + 12 = 35 ✓ e 2(23) + 4(12) = 46 + 48 = 94 ✓",
    points: 30,
  },
  {
    category: "sistema_equacoes",
    difficulty: 5,
    statement:
      "A soma de dois números é 40. O maior excede o triplo do menor em 4. Qual é o menor número?",
    optionA: "7",
    optionB: "8",
    optionC: "9",
    optionD: "10",
    correctOption: "C",
    explanation:
      "Seja x o maior e y o menor.\n\nSistema:\nx + y = 40\nx = 3y + 4\n\nSubstituindo:\n3y + 4 + y = 40\n4y + 4 = 40\n4y = 36\ny = 9\n\nx = 3(9) + 4 = 31\n\nVerificação: 31 + 9 = 40 ✓ e 31 = 3(9) + 4 = 27 + 4 = 31 ✓",
    points: 30,
  },
  {
    category: "sistema_equacoes",
    difficulty: 5,
    statement:
      "Um cinema vendeu 800 ingressos. Ingressos inteiros custam R$ 30 e meias-entradas custam R$ 15. A arrecadação total foi R$ 18.000. Quantos ingressos inteiros foram vendidos?",
    optionA: "350",
    optionB: "400",
    optionC: "450",
    optionD: "500",
    correctOption: "B",
    explanation:
      "Seja i = ingressos inteiros e m = meias-entradas.\n\nSistema:\ni + m = 800\n30i + 15m = 18000\n\nDa 1ª: m = 800 - i\n\nSubstituindo:\n30i + 15(800 - i) = 18000\n30i + 12000 - 15i = 18000\n15i = 6000\ni = 400\n\nm = 800 - 400 = 400\n\nVerificação: 400 + 400 = 800 ✓ e 30(400) + 15(400) = 12000 + 6000 = 18000 ✓",
    points: 30,
  },
];

export async function seed() {
  const existing = await db.select().from(questions).limit(1);
  if (existing.length > 0) {
    console.log("Questions already seeded, skipping...");
    return;
  }
  await db.insert(questions).values(seedQuestions);
  console.log(`Seeded ${seedQuestions.length} questions`);
}
